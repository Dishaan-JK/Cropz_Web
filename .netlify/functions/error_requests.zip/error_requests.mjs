
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/error_requests.mjs
var PB_BASE_URL = process.env.PB_BASE_URL || "https://cropzcard.pockethost.io";
var PB_ERROR_REQUESTS_COLLECTION = process.env.PB_ERROR_REQUESTS_COLLECTION || "Error Requests";
var PB_AUTH_TOKEN = process.env.PB_AUTH_TOKEN?.trim() || "";
function jsonResponse(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    }
  });
}
function toStringValue(value) {
  if (value === null || value === void 0) {
    return "";
  }
  return String(value).trim();
}
function normalizePayload(payload) {
  return {
    requester_name: toStringValue(payload?.requester_name),
    requester_email: toStringValue(payload?.requester_email),
    issue_type: toStringValue(payload?.issue_type),
    date_noticed: toStringValue(payload?.date_noticed),
    page_or_screen: toStringValue(payload?.page_or_screen),
    device_browser: toStringValue(payload?.device_browser),
    what_happened: toStringValue(payload?.what_happened),
    expected_result: toStringValue(payload?.expected_result),
    steps_tried: toStringValue(payload?.steps_tried),
    additional_details: toStringValue(payload?.additional_details),
    source_url: toStringValue(payload?.source_url),
    source_path: toStringValue(payload?.source_path),
    status: toStringValue(payload?.status) || "open",
    source: toStringValue(payload?.source) || "web"
  };
}
function missingRequiredFields(record) {
  const required = [
    "requester_name",
    "requester_email",
    "issue_type",
    "date_noticed",
    "page_or_screen",
    "device_browser",
    "what_happened"
  ];
  return required.filter((key) => !record[key]);
}
async function createPocketBaseRecord(record) {
  const endpoint = `${PB_BASE_URL.replace(/\/+$/, "")}/api/collections/${encodeURIComponent(PB_ERROR_REQUESTS_COLLECTION)}/records`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...PB_AUTH_TOKEN ? { Authorization: `Bearer ${PB_AUTH_TOKEN}` } : {}
    },
    body: JSON.stringify(record)
  });
  const body = await response.text();
  if (!response.ok) {
    throw new Error(`pocketbase returned ${response.status}: ${body.trim()}`);
  }
  try {
    return JSON.parse(body);
  } catch (error) {
    throw new Error(`invalid pocketbase JSON: ${error instanceof Error ? error.message : String(error)}`);
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") {
    return jsonResponse(204, {});
  }
  if (req.method !== "POST") {
    return jsonResponse(405, { error: "method not allowed" });
  }
  let payload;
  try {
    payload = await req.json();
  } catch (error) {
    return jsonResponse(400, { error: "invalid JSON body" });
  }
  const record = normalizePayload(payload);
  const missing = missingRequiredFields(record);
  if (missing.length > 0) {
    return jsonResponse(400, {
      error: "missing required fields",
      missing
    });
  }
  try {
    const saved = await createPocketBaseRecord(record);
    return jsonResponse(201, saved);
  } catch (error) {
    return jsonResponse(502, {
      error: error instanceof Error ? error.message : String(error)
    });
  }
}
export {
  handler as default
};
